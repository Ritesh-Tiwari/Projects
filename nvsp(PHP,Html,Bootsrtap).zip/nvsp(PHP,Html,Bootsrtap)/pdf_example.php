<?php
require('fpdf/fpdf.php');
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    // $this->Image('logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(60);
    // Title
    $this->Cell(80,10,'User Information',1,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$conn=mysqli_connect("localhost","root","","nvsp") or die("database not be connceted");
$sql = "select *from register where Email='a@gmail.com'";
$result = mysqli_query($conn, $sql);

$number_of_products = mysqli_num_rows($result);

//Initialize the 3 columns and the total
$fname = "";
$lname = "";
$epic = "";
$mobile = "";
$Email = "";
$Password = "";
$father_name="";
$DOB="";
$gender="";
$state="";
$district="";
$code="";
 
$pic="";
//For each row, add the field to the corresponding column
while($row = mysqli_fetch_array($result))
{

  $fname=$row["F_Name"];
  $lname=$row["L_Name"];
  $pic=$row['Profile_Pic'];
  $father_name=$row['Father/Husband_Name'];
  $DOB=$row['DOB'];
  $gender=$row['Gender'];
  $epic = $row["EPIC_Number"];
  $mobile =$row["Mobile_No"];
  $Email=$row["Email"];
  $district=$row['district_Name'];
  $state=$row['State_Name'];
  $code=$row['Code'];
  $pass=$row["Password"];
  
  
  
  // $column_fname = $column_fname.$fname."\n";
  // $column_lname = $column_lname.$lname."\n";
  // $column_epic  = $column_epic.$epic."\n"; 
  // $column_mobile= $column_mobile.$mobile."\n";
  // $column_Email = $column_Email.$Email."\n";
  // $column_Password=$column_Password.$pass."\n"; 


}
mysqli_close($conn);

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','B',12);
 
$pdf->sety(50);
$pdf->SetX(70);
$pdf->Cell(30,1,'Name ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(20,1,$fname,0,0,'L',1);
$pdf->SetX(135);
$pdf->Cell(20,1,$lname,0,0,'L',1);

$pdf->sety(60);
$pdf->SetX(70);
$pdf->Cell(30,1,'Profile Pic ',0,0,'L',1);
$pdf->SetX(120);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
// $pdf->sety(60);
$pdf->Image($pic,120,60,17);
// $pdf->Cell(10,1,$pic,0,0,'L',1);

$pdf->sety(85);
$pdf->SetX(70);
$pdf->Cell(30,1,'Father/Husband Name ',0,0,'L',1);
$pdf->SetX(117);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$father_name,0,0,'L',1);

$pdf->sety(95);
$pdf->SetX(70);
$pdf->Cell(30,1,'DOB',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$DOB,0,0,'L',1);

$pdf->sety(105);
$pdf->SetX(70);
$pdf->Cell(30,1,'Gender',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$gender,0,0,'L',1);

$pdf->sety(115);
$pdf->SetX(70);
$pdf->Cell(30,1,'EPIC Number ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$epic,0,0,'L',1);

$pdf->sety(125);
$pdf->SetX(70);
$pdf->Cell(30,1,'Mobile No ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$mobile,0,0,'L',1);

$pdf->sety(135);
$pdf->SetX(70);
$pdf->Cell(30,1,'E-mail ID ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$Email,0,0,'L',1);

$pdf->sety(145);
$pdf->SetX(70);
$pdf->Cell(30,1,'District Name ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$district,0,0,'L',1);

$pdf->sety(155);
$pdf->SetX(70);
$pdf->Cell(30,1,'State Name ',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$state,0,0,'L',1);

$pdf->sety(165);
$pdf->SetX(70);
$pdf->Cell(30,1,'Code',0,0,'L',1);
$pdf->SetX(110);
$pdf->Cell(10,1,"-",0,0,'L',1);
$pdf->SetX(120);
$pdf->Cell(10,1,$code,0,0,'L',1);


$pdf->Output('my_profile.pdf','I');
 
//header("location:nvsp.php?id=$id");
 
 ?>
 