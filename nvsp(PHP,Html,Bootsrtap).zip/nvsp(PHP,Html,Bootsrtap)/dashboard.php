<?php
$id=$_GET['id'];
// echo $id;
$conn=mysqli_connect("localhost","root","","nvsp") or die("database not be connceted");
$sql = "select *from register where Email='$id'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {

?>


<html>

<head>

    <link rel="icon" href="../Images/eci-icon.ico" type="image/x-icon">

    <meta charset="utf-8">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>

</head>
<style>
    form {
        border-style: groove;
    }
    
    .form-control {
        border-radius: 10px;
        background-color: rgb(218, 198, 194);
    }
    
    .form-control:focus {
        border-radius: 10px;
        background-color: rgb(17, 9, 7);
        color: white;
    }
    
    .btn_submit {
        background-color: rgb(124, 29, 6);
        color: wheat;
        height: 50px;
        width: 80%;
        line-height: 50px;
        margin-top: 20;
        margin-bottom: 20;
        border-radius: 20px;
    }
    
    .btn_submit:hover {
        background-color: rgb(105, 165, 8);
    }
    
    #submit {
        background-color: transparent;
        border-style: none;
        color: wheat;
        font-size: 22;
    }
</style>
<!--
<script type="text/javascript">
        window.history.forward();
        function noBack()
        {
            window.history.forward();
        }
</script>
</head>

<body onLoad="noBack();" onpageshow="if (event.persisted) noBack();" onUnload="">
-->
</head>
<body>

<header>

<nav class="navbar navbar-expand-lg bg-white  navbar-light">
   <a class='navbar-link' style='margin-left: 2%;' href='nvsp.php?id=<?php echo $id;?>'><span><img src='Images/logo.png'></span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
     <span class="navbar-toggler-icon  "></span>
    </button>
    <div class="collapse navbar-collapse " id="collapsibleNavbar">
        <ul class="navbar-nav ml-md-auto font-weight-bolder ">

            <li class="nav-item p-lg-3  ">
                <?php echo "<a class='nav-link' href='nvsp.php?id=$id'>Home</a>";?>
              
            </li>
            <li class="nav-item p-lg-3">
                <a class="nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item p-lg-3 dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                Service
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item nav-link" href="#">Elector Verification Program</a>
                    <a class="dropdown-item nav-link" href="#">Track Status</a>
                    <a class="dropdown-item nav-link" href="#">Family Tagging</a>
                </div>
            </li>
           
            <li class="nav-item p-lg-3  ">
                <?php echo "<a class='nav-link' href='dashboard.php?id=$id'>Dashboard</a>";?>
              
            </li>
            <li class="nav-item p-lg-3 dropdown">
                <img src="Images/login_logo.jpg" width="50px" height="50px" class="nav-link dropdown-toggle" id="navbardrop" data-toggle="dropdown">
                            <!-- <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">

                </a> -->
                <div class="dropdown-menu">
                     <?php echo "<a class='dropdown-item nav-link' href='my_profile.php?id=$id'>View Profile</a>";?>
                     <a class="dropdown-item nav-link" href="login.html">LogOut</a>
                  </div>
            </li>

        </ul>
    </div>

</nav>
</header>

    <div class=" container">
        <form action="update_dashboard.php" method="POST" enctype="multipart/form-data" target="_blank" style="border-style:groove; margin: 5 5 5 5;">
            <div class="row">
                    <!-- pass user ID -->
                <input type="hidden" value="<?php echo $id?>" name="hidden">

                <div class=" col-lg-6 col-sm-6 ">
                    <div class="col-lg-1"></div>
                    <div class="col-lg-4">
                        <label for="fname" class="control-label">First Name </label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="text" class="form-control" name="fname_text" id="fname_text" value="<?php echo $row['F_Name'];?>" placeholder="First Name (Required)" autocomplete="off" required/>
                        <h5 class="text-center text-danger" id="fname_check"></h5>
                    </div>
                    <div class="col-lg-1"></div>
                    <div class="col-lg-4">
                        <label for="lname" class="control-label">Last Name </label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="text" class="form-control" name="lname_text" id="lname_text" value="<?php echo $row['L_Name'];?>" placeholder="Last Name (Required)" autocomplete="off" required/>
                        <h5 class="text-center text-danger" id="lname_check"></h5>
                    </div>
                </div>

                <div class=" col-lg-4 col-sm-6 ">

                    <div class="col-lg-12">
                        <label for="pic" class="control-label">Profile Picture  </label>
                    </div>
                    <div class="col-lg-12">
                        <img src="<?php echo $row['Profile_Pic'];?>" height="100px" width="100px" alt="profile"> </img>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="file" name="profile_pic" id="profile_pic" value="<?php echo $row['Profile_Pic'];?>">
                        <h5 class="text-center text-danger" id="profile_pic_check"></h5>

                    </div>
                </div>



            </div>

            <div class="row">
                <div class=" col-lg-6 col-sm-12 ">
                    <div class="col-lg-12 ">
                        <label for="Fathers Name" class="control-label">Father's/Husband's Name*</label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="text" class="form-control" name="father_name_text" id="father_name_text" value="<?php echo $row['Father/Husband_Name'];?>"  placeholder="Father/Husband Name (Required)" autocomplete="off" required/>
                        <h5 class="text-center text-danger" id="father_name_check"></h5>
                    </div>
                </div>
                <div class=" col-lg-4 col-sm-12">

                    <div class="col-12 ">
                        <label for="Mobile_no " class="control-label">Mobile No *</label>
                    </div>
                    <div class="col-lg-12">
                        <input type="text" id="Mobile_no_text" name="Mobile_no_text"  value="<?php echo $row['Mobile_No'];?>" class="form-control" autocomplete="off" required/>
                        <h5 class="text-center text-danger" id="mobile_check"></h5>

                    </div>
                </div>
                <div class=" col-lg-6 col-sm-12">

                    <div class="col-12 ">
                        <label for="email " class="control-label">E-mail ID *</label>
                    </div>
                    <div class="col-12 ">
                        <input type="email" id="email_text" name="email_text" value="<?php echo $row['Email'];?>" class="form-control" placeholder="E-mail ID" autocomplete="off" required/>
                        <h5 class="text-center text-danger" id="email_check"></h5>
                    </div>
                </div>
                <div class=" col-lg-3 col-sm-6">

                    <div class="col-lg-12">
                        <label for="DOB " class="control-label">DOB *</label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="date" id="date" name="DOB" id="DOB" value="<?php echo $row['DOB'];?>" class="form-control" min="1960-01-01" max="2000-12-31">
                        <h5 class="text-center text-danger" id="DOB_check"></h5>
                    </div>
                </div>
                <div class=" col-lg-3 col-sm-6">
                    <div class="col-lg-12 ">
                        <label for="Gender" class="control-label">Gender</label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="radio" name="radio" value="male">Male
                        <input type="radio" name="radio" value="Female">Female
                        <input type="radio" name="radio" value="Other">Other
                    </div>
                    <h5 class="text-center text-danger" id="gender_check"></h5>
                </div>
                <div class=" col-lg-6 col-sm-12 ">

                    <div class="col-lg-5 ">
                        <label for="State " class="control-label ">State * </label>
                    </div>
                    <div class="col-lg-12 ">
                        <input type="text " class="form-control " name="state_text" id="state_text" value="<?php echo $row['State_Name'];?>" placeholder="State Name (Required) " autocomplete="off " required/>
                        <h5 class="text-center text-danger" id="state_check"></h5>
                    </div>
                </div>
                <div class=" col-lg-6 col-sm-12 ">
                    <div class="col-lg-5 ">
                        <label for="State " class="control-label ">District</label>
                    </div>
                    <div class="col-lg-8">
                        <input type="text " class="form-control " name="district_text" id="district_text" value="<?php echo $row['district_Name'];?>" placeholder="District Name (Required) " autocomplete="off " required/>
                        <h5 class="text-center text-danger" id="district_check"></h5>
                    </div>
                </div>



                <div class=" col-lg-6 col-sm-12 ">
                    <div class="col-lg-6 ">
                        <label for="Code " class="control-label ">Code *</label>
                    </div>

                    <div class="col-lg-6 ">
                        <input type="text " class="form-control " name="code_text" id="code_text" value="<?php echo $row['Code'];?>" placeholder="Code (Required) " autocomplete="off " required/>
                    </div>
                    <h5 class="text-center text-danger" id="code_check"></h5>
                </div>
                <div class=" col-lg-6 col-sm-12 "></div>
                <div class=" col-lg-2 col-sm-2 "></div>
                <div class=" col-lg-8 col-sm-8 text-center btn_submit">
                    <input type="submit" name="submit" id="submit" value="Submit">
                </div>
                <div class=" col-lg-2 col-sm-2 "></div>


            </div>

    </div>

    </form>
    <?php   } } else {echo "Records not found";} mysqli_close($conn); ?>
       
    </div>





    <footer class="container-fluid mt-2" style="background-color: rgb(12, 89, 109); width: 100%;">
        <div class="row">
            <div class="col-lg-7 col-sm-12">
                <div class="text-white text-capitalize pt-3">
                    <h2>contact us</h2>
                </div>
                <div>
                    <p class="text-light pt-3 ">For details of eligibility criteria or any other additional information related to electoral forms, kindly visit<a href="#"> https://eci.gov.in</a></p>
                </div>
                <div>
                    <p class="text-light">For any other technical feedback or issues on the portal kindly send your feedback to ECI Technical Support Toll free Number :1800111950</p>
                </div>
            </div>
            <div class=" col-lg-5 col-sm-12 ">
                <div class="text-white text-capitalize pt-lg-3 ">
                    <h2>Other Links</h2>
                </div>
                <div class="text-capitalize font-weight-bold pt-3 ">
                    <a class="text-white " href="# ">Election Commission of India</a>
                </div>
                <div class="text-capitalize font-weight-bold pt-3 ">
                    <a class="text-white " href="# ">Chief Electoral Officer</a>
                </div>
            </div>
            <div class="col-12 text-center text-white ">
                <hr class="bg-light ">
                <p>National Voter's Service Portal © Copyright 2019. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

</body>
<script>
    $(document).ready(function() {
        $("#fname_check").hide();
        $("#fname_check").hide();
        $("#profile_pic_check").hide();
        $("#father_name_check").hide();
        $("#mobile_check").hide();
        $("#email_check").hide();
        $("#DOB_check").hide();
        $("#gender_check").hide();
        $("#state_check").hide();
        $("#district_check").hide();
        $("#code_check").hide();


        var fname_err = true;
        var lname_err = true;
        var profile_pic_err = true;
        var father_err = true;
        var mobile_err = true;
        var email_err = true;
        var DOB_err = true;
        var gender_err = true;
        var stata_err = true;
        var district_err = true;
        var code_err = true;
        $("#fname_text").keyup(function() {
            fname_check();
        });
        $("#lname_text").keyup(function() {
            lname_check();
        });
        // $("#email_text1").keyup(function() {
        //     email_check();
        // });
        $("#father_name_text").keyup(function() {
            father_name_check();
        });
        $("#Mobile_no_text").keyup(function() {
            mobile_check();
        });
        $("#email_text").keyup(function() {
            email_check();
        });
        $("#DOB").keyup(function() {
            DOB_check();
        });
        $("#state_text ").keyup(function() {
            state_check();
        });
        $("#district_text ").keyup(function() {
            district_check();
        });
        $("#code_text ").keyup(function() {
            code_check();
        });

        function fname_check() {
            var fname = $("#fname_text").val();
            if (fname.length == 0) {
                $("#fname_check").show();
                $("#fname_check").html("** Please Fill the First Name...");
                $("#fname_check").focus();
                lname_err = false;

            } else {
                $("#fname_check").hide();
                fname_err = true;
            }
        }

        function lname_check() {
            var lname = $("#lname_text").val();
            if (lname.length == 0) {
                $("#lname_check").show();
                $("#lname_check").html("** Please Fill the Last Name...");
                $("#lname_check").focus();
                lname_err = false;

            } else {
                $("#lname_check").hide();
                lname_err = true;
            }
        }

        function father_name_check() {
            var father_name_val = $("#father_name_text").val();
            if (father_name_val.length == 0) {
                $("#father_name_check").show();
                $("#father_name_check").html("** Please Fill the Father Name...");
                $("#father_name_check").focus();
                father_err = false;

            } else {
                $("#father_name_check").hide();
                father_err = true;
            }
        }

        function mobile_check() {
            var no = $("#Mobile_no_text").val();
            if (no.length == 0) {
                $("#mobile_check").show();
                $("#mobile_check").html("** Please Fill the Mobile Number...");
                $("#mobile_check").focus();
                mobile_err = false;
            } else if (no.length != 10) {
                $("#mobile_check").show();
                $("#mobile_check").html("** You have entered an invalid Mobile Number !");
                $("#mobile_check").focus();
                return false;
            } else {
                $("#mobile_check").hide();
                mobile_err = true;
            }
        }

        function email_check() {
            var email_val1 = $("#email_text").val();
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

            if (email_val1.length == 0) {
                $("#email_check").show();
                $("#email_check").html("** Please Fill the E-mail ID...");
                $("#email_check").focus();
                email_err1 = false;

            } else if (mailformat.test(email_val1)) {
                $("#email_check").hide();
                email_err = true;

            } else {
                $("#email_check").show();
                $("#email_check").html("** You have entered an invalid E-mail address!");
                $("#email_check").focus();
                email_err = false;
            }
        }

        function state_check() {
            var State = $("#state_text ").val();
            if (State.length == 0) {
                $("#state_check").show();
                $("#state_check").html("** Please Fill the State Name...");
                $("#state_check").focus();
                stata_err = false;

            } else {
                $("#state_check").hide();
                stata_err = true;
            }

        }

        function district_check() {
            var district = $("#district_text ").val();
            if (district.length == 0) {
                $("#district_check").show();
                $("#district_check").html("** Please Fill the District Name...");
                $("#district_check").focus();
                district_err = false;

            } else {
                $("#district_check").hide();
                district_err = true;
            }
        }

        function code_check() {
            var code = $("#code_text").val();
            if (code.length == 0) {
                $("#code_check").show();
                $("#code_check").html("** Please Fill the Code...");
                $("#code_check").focus();
                lname_err = false;

            } else {
                $("#code_check").hide();
                code_err = true;
            }
        }





    });
</script>

</html>