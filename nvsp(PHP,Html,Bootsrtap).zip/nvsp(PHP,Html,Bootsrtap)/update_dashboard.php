<html>
<body>
<style>
    body{
        background-color:tomato;
    }
    table {
        width:60%;
        border-style: groove;
        border-color: brown;
        background-color: rgb(240, 129, 129);
        margin-left:20%;
        margin_right:10%;
        margin-top:10px;
        margin-buttom:10px;
    }

    
    h1{ 
        color: rgb(90, 5, 52);
        text-align: center;
    }
    
    td {
        padding:10 0 10 0;
        font-size: 20px;
        color: rgb(196, 240, 146);
        background-color: rgb(236, 160, 110);
       
    }
</style>
<?php
$fname=$_POST["fname_text"];
$lname=$_POST["lname_text"];
$father_name=$_POST["father_name_text"];
$pic=$_FILES['profile_pic'];
$mobile_no=$_POST["Mobile_no_text"];
$Email=$_POST["email_text"];
$id=$_POST["hidden"];
$DOB=$_POST['DOB'];
$gender=$_POST["radio"];
$state=$_POST["state_text"];
$district=$_POST["district_text"];
$code=$_POST["code_text"];
//echo $id;


//collect File Name
$file_name=$pic['name'];
$file_err=$pic['error'];
$file_temp=$pic['tmp_name'];
$file_ext=explode('.',$file_name);

$file_check=strtolower(end($file_ext));
$file_ext_stored=array('png','jpg','jpeg');

if(in_array($file_check,$file_ext_stored))
    {
        $destination_file='Images/upload/'.$file_name;
        move_uploaded_file($file_temp,$destination_file);
    }

// insert Data
$conn=mysqli_connect("localhost","root","","nvsp") or die("database not be connceted");
$sql = "UPDATE `register` SET `F_Name`='$fname',`L_Name`='$lname',`Profile_Pic`='$destination_file',`Email`='$Email',`Mobile_No`='$mobile_no',`Father/Husband_Name`='$father_name',`State_Name`='$state',`DOB`='$DOB',`Gender`='$gender',`Code`='$code',`district_Name`='$district' WHERE Email='$id'";

if (mysqli_query($conn, $sql)) {
     echo "<h1>User information</h1><hr>";
   //  header("location:dashboard.php?id=$id");
} else {
    echo "<h3style='text-aligin:center; color:blue;'>Error updating record: ", mysqli_error($conn),"</h3style='text-aligin:center;>";
    echo "<br><center><a  href='dashboard.php?id=$id'>Go Back</a></center>";
}

// display Date
$display = "select *from register where Email='$id'";
$result = mysqli_query($conn, $display);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        ?>
        <a href="pdf_example.php?id=<?php echo $id ?>" style="margin-left:70%; font-size:20px; color:white"target="_blank" >Download Pdf</a>
        <table width=800 border="5">
            <!-- <th colspan="2" aligin='center'><h3>User Information</h3></!--> 
            <tr>
            <td>Name </td>
            <td><?php echo $row['F_Name'],$row['L_Name'];?></td>
            </tr>
            <tr>
            <td>Profile Pic </td>
            <td><img src="<?php echo $row['Profile_Pic'];?>" height="100px" width="100px" alt="profile"> </img></td>
            </tr>
            <tr>
            <td>Father/Husband Name </td>
            <td><?php echo $row['Father/Husband_Name'];?></td>
            </tr>
            <tr>
            <td>Gender </td>
            <td><?php echo $row['Gender'];?></td>
            </tr>
           
            <tr>
            <td>EPIC Number</td>
            <td><?php echo $row['EPIC_Number'];?></td>
            </tr>
           
            <tr>
            <td>Mobile No</td>
            <td><?php echo $row['Mobile_No'];?></td>
            </tr>
            <td>E-mail ID</td>
            <td><?php echo $row['Email'];?></td>
            </tr>
            <tr>
            <td>DOB </td>
            <td><?php echo $row['DOB'];?></td>
            </tr>
           
            <tr>
            <td>Code</td>
            <td><?php echo $row['Code'];?></td>
            </tr>
           
            <tr>
            <td>District Name</td>
            <td><?php echo $row['district_Name'];?></td>
            </tr>
           
        </table>
        <a href="pdf_example.php?id=<?php echo $id ?>" style="margin-left:70%; font-size:20px; color:white" target="_blank" >Download Pdf</a>
       
<?php
    }
}        
   
mysqli_close($conn);
?>

</body>
</html>
