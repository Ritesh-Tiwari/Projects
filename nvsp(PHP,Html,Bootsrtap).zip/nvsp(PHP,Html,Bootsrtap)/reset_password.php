<?php
    $no=$_POST['no'];
    $pass=$_POST['new_pass'];
   
   echo $pass;
   echo $no;
    $conn=mysqli_connect("localhost","root","","nvsp") or die("database not be connceted");
    $query="select *from register where Mobile_No='$no';";
    $result=mysqli_query($conn,$query);
    $no=mysqli_num_rows($result);
    if($no>=1)
    {
       $query = "UPDATE register SET Password='$pass' WHERE Mobile_No='$no';";

            if (mysqli_query($conn, $query)) {
            echo "<h3 style='text-aligin:center; color:blue;'>Password Change successfully</h3>";
                 // header("location:my_profile.php?id=$id");
            } 
            else {

                  echo "<h3 style='text-aligin:center; color:blue;'>Error updating record: . mysqli_error($conn);</h3>";
                  echo "<br><center><a  href='my_profile.php?id=$id'>Go Back</a></center>";
                            
                }
  }else{
      echo "<h3 style='text-aligin:center; color:white; padding:20 20 20 20; background-color:red'>Wrong Password . mysqli_error($conn);</h3>";
      echo "<br><center><a  href='reset_password.php?id=$id'>Go Back</a></center>";
             
  }
?>