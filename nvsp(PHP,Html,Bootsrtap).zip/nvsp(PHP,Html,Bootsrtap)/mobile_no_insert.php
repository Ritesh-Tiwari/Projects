<?php
  $con=mysqli_connect("localhost","root");
  if(!$con)                                    //checking connection
  {
      die("could not connect:".mysql_error());
  }
  mysqli_select_db($con,"nvsp");
extract($_POST);
if(isset ($_POST['a'])){
	   
    $check="SELECT * FROM `mobile_no` where Mobile_no='$a' ";
    
    $result=mysqli_query($con,$check);
	$no=mysqli_num_rows($result);
	if($no>=1)
	{
		echo"This number is all ready used...";
     //mysqli_query($con,$sql1);
    
	}
else{
    
	 $sql = "INSERT INTO `mobile_no` (`Mobile_no`) VALUES ('$a');";
    //$sql1 = "INSERT INTO `register` (`Mobile_No`) VALUES ('$a');";
    mysqli_query($con,$sql);
    echo"Number Saved...";
   
    
	}
}

?>